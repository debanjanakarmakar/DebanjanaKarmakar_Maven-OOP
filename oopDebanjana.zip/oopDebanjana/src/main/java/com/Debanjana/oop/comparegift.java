package com.Debanjana.oop;
import java.util.Comparator;
public class comparegift implements Comparator<Gift>{

		 public int compare(Gift e1, Gift e2){
		  if(e1.getWeight()>e2.getWeight())
		  {
			  return 1;
		 }
		  else
			  return 0;
		 }
		 
		 public String toString(){
		  return "comparegift";
		 }
}

