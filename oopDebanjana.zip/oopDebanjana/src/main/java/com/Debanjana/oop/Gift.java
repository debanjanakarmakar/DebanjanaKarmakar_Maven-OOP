package com.Debanjana.oop;

abstract public class Gift implements Name{
	private double weight;
	private double price;
	private String name;
	
	public void set(String a,double x,double y)
	{
		this.name=a;
		this.price=x;
		this.weight=y;
	}
	public Gift()
	{
		weight=0;
		price=0;
		name="";
	}
	public double getWeight()
	{
		return weight;
	}
	
	public double getPrice()
	{
		return price;
	}
	
	public String getname()
	{
		return name;
	}
	abstract public void display();
	
}
