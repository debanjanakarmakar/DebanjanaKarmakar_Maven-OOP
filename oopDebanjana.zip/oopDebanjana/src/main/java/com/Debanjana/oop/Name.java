package com.Debanjana.oop;

public interface Name {
	public void set(String a,double x,double y);

}
