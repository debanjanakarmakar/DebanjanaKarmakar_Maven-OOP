package com.Debanjana.oop;

public class Chocolate extends Gift{
	private String category;
	
	public void setCat(String c)
	{
		category=c;
	}
	
	public String getCat()
	{
		return category;
	}
	public Chocolate(String n,String c,double co,double x) {
		 set(n,co,x);
		 category=c;
	}
	
	
	public void display()
	{
		System.out.println("Name="+getname());
		System.out.println("Category="+category);
		System.out.println("Weight="+getWeight());
		System.out.println("Price="+getPrice());
		

	}
}
