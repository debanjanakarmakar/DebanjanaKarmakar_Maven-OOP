package com.Debanjana.oop;

public class Sweet extends Gift{

private String type;
	
	public void setType(String t)
	{
		type=t;
	}
	public  String getType()
	{
		return type;
	}
	public Sweet(double x,double y,String name,String r)
	{
		set(name,x,y);
		type=r;
	}

	public void display()
	{
		System.out.println("Name="+getname());
		System.out.println("Type="+type);
		System.out.println("Weight="+getWeight());
		System.out.println("Price="+getPrice());
		

	}
}
