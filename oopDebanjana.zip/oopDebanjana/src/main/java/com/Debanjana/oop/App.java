package com.Debanjana.oop;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class App  
{
    @SuppressWarnings("resource")
	public static void main( String[] args )throws IOException
    {
    	int n,n2;
		String a,b;
		double x,y;
		Scanner sn=new Scanner(System.in);
		System.out.println("Enter the number of gifts which are chocolates:");
		
		n=sn.nextInt();
		List<Chocolate>listOfChoc= new ArrayList<Chocolate>();
		System.out.println("Enter the name,price and weight and category of chocolates");
		for(int i=0;i<n;i++)
		{
			
			a=sn.next();
			x=sn.nextDouble();
			y=sn.nextDouble();
			b=sn.next();
			System.out.println("Entered");
			Chocolate c = new Chocolate(a, b, x, y);
			listOfChoc.add(c);
			
		}
		
		
		System.out.println("Enter the number of gifts which are sweets:");
		
		
		 n2=sn.nextInt();
		 List<Sweet>listOfSweet=new ArrayList<Sweet>();
		 
		 System.out.println("Enter the name,price and weight and type of sweets");
		 for(int i=0;i<n2;i++) 
		 { 
			 a=sn.next(); 
			 x=sn.nextDouble();
			 y=sn.nextDouble();
			 b=sn.next();
			 
			 Sweet s=new Sweet(x,y,a,b);
			 
			 listOfSweet.add(s);
			 
		 }
		 List<Gift>gift=new ArrayList<Gift>();
		 		 
		
		 for(int i=0;i<n;i++)
		 {
			 gift.add(listOfChoc.get(i));
		 }
		 for(int i=0;i<n2;i++)
		 {
			 gift.add(listOfSweet.get(i));
		 }
		 
		 
		 System.out.println("Sorting according to weight:\n ");
		 
		 double s=0;
		 //Sorting in ascending order of weights
			
		 comparegift obj=new comparegift();
		 
		 gift.sort(obj);
		 
		 for(Gift g:gift)
		 {
			 g.display();
			 System.out.println();
		 }
		
		 //Printing total weight of gifts
		 for(Gift o:gift) {
	            s+=o.getWeight();
	        }
		 
		 System.out.println("Sum of weights:"+s);
		 
		 //Finding gifts in a price range
		 System.out.println("Enter the range for prices:");
		 double l=sn.nextDouble();
		 double h=sn.nextDouble();
		 
		 System.out.println("List of gifts in the given range:");
		 for(Gift o:gift) {
	            double p=o.getPrice();
	            if(p>=l && p<=h)
	            {
	            	o.display();
	            	System.out.println("\n\n");
	            }
	        }
	
    }
}
